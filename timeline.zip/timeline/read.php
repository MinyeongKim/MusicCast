<?php
//include "../db.php";

header('Content-Type: text/html; charset=utf-8');

$mysql_hostname = 'localhost';
$mysql_username = 'root';
$mysql_password = 'apmsetup';
$mysql_database = 'boardtest';

// DB 연결
$connect = mysql_connect($mysql_hostname, $mysql_username, $mysql_password);
// DB 선택
mysql_select_db($mysql_database, $connect) or die('DB 선택 실패');

	$bno = $_GET["indx"];
	$sql = "select * from board where indx='".$bno."'";

	$result = mysql_query($sql, $connect);
	$board = mysql_fetch_array($result);
/* 조회수 카운트 */

	$sql_hit = "select * from board where indx ='".$bno."'";
	$result_hit = mysql_query($sql_hit,$connect);
	$hit = mysql_fetch_array($result_hit);
	$hit = $hit['hit'] + 1;
	$fet = mysql_query("update board set hit = '".$hit."' where indx = '".$bno."'", $connect);


	?>
<!doctype html>
<html lang="ko">
 <head>
  <meta charset="UTF-8">
  <title>게시판</title>
  <link rel="stylesheet" href="../style.css" />
 </head>
 <body>
 <form action="write_ok.php" method="post">
                    <table id="boardWrite">
                        <tr>
                            <td class="tb"><label for="uname">이름</label></td>
                            <td height="30"><input type="text" name="name" id="uname" size="50" class="inh"/></td>
                        </tr>
                        <tr>
                            <td class="tb"><label for="upw">비밀번호</label></td>
                            <td height="30"><input type="password" name="pw" id="upw" size="50"/></td>
                        </tr>
                        <tr>
                            <td class="tb"><label for="utitle">제목</label></td>
                            <td height="30"><input type="text" name="title" id="utitle" size="50"/></td>
                        </tr>
                        <tr>
                            <td class="tb"><label for="ucontent">내용</label></td>
                            <td height="30"><textarea name="content" id="ucontent" rows="10" cols="37"></textarea></td>
                        </tr>
                    </table>
                <div class="bt_se">
                    <button>작성</button>
                </div>
            </form>
 <div id="board_read">
<table>
	<tr>
		<td class="read w10 fl">제목</td>
		<td class="read_con">&nbsp;<?php echo $board['title'];?></td>
	</tr>
	<tr>
		<td class="read w5 fl">번호</td>
		<td class="read_con">&nbsp;<?php echo $board['indx'];?></td>
	</tr>
	<tr>
		<td class="read w10 fl">작성자</td>
		<td class="read_con">&nbsp;<?php echo $board['name'];?></td>
	</tr>
	<tr>
		<td class="read w10 fl">등록일</td>
		<td class="read_con">&nbsp;<?php echo $board['date'];?></td>
	</tr>
	<tr>
		<td class="read w10 fl">조회수</td>
		<td class="read_con">&nbsp;<?php echo $board['hit']+1;?></td>
	</tr>
	<tr>
		<td class="read_nl fl">내용</td>
		<td class="read_nl_con"><?php echo nl2br("$board[content]");  ?></td>
		<td><?php echo("<br><br><video src=test.mp4 controls></video>");?></td>
	</tr>
</table>
</div>
<div class="bo_ser">
	<ul>
		<li><a href="index.php">[목록으로]</a></li>
		<li><a href="modify.php?indx=<?php echo $board['indx']; ?>">[수정]</a></li>
		<li><a href="delete.php?indx=<?php echo $board['indx']; ?>">[삭제]</a></li>
	</ul>
</div>


<h1>댓글</h1>

		<div id ="board_area">
			<table class = "list-table">
				<thead>
				<tr>
				<th width ="70">번호</th>
				<th width ="500">내용</th>
				<th width ="120">글쓴이</th>
				<th width ="100">작성일</th>
				<th width ="100">조회수</th>
				</tr>
				</thead>
<?php

$mysql_hostname = 'localhost';
$mysql_username = 'root';
$mysql_password = 'apmsetup';
$mysql_database = 'boardtest';

// DB 연결
$connect = mysql_connect($mysql_hostname, $mysql_username, $mysql_password);

// DB 선택
mysql_select_db($mysql_database, $connect) or die('DB 선택 실패');

   $sql = "select * from board order by indx desc limit 0,5";
   // mq - mysql_query 의 약자
   // BoardTest 안의 모든 컬럼들을 가져오고 index 번호에 따라 내림차순으로 5개 출력.
   $result = mysql_query($sql, $connect);
   //echo $result;
   while($board = mysql_fetch_array($result)){
   // 보냈던 쿼리의 행이 끝날때까지 자동으로 반복실행
   $title = $board[title]; // board 테이블의 title 값 저장
   if(strlen($title)>30){
      $title = str_replace($board[title],mb_substr($board[title],0,30,"utf-8")."...",$board['title']);
      // 제목이 일정 길이 초과시 초과한 문자 대신 '...' 출력 (31 부터는 ... 출력)
   }
?>

<tbody>
<tr>
<td width="70"><?php echo $board['indx']; ?></td>
<td width="500"><?php echo $board['content'];?></a></td>
<!-- 글을 읽을때 해당 글의 번호를 가져옴 -->
<td width="120"><?php echo $board['name']; ?></td>
<td width="100"><?php echo $board['date']; ?></td>
<td width="100"><?php echo $board['hit']; ?></td>
</tr>
</tbody>
<?php } ?>
</table>
<form action="write.php">
<div class="write_btn">
<!--<button>글쓰기</button>-->
</div>
</form>
</div>





 </body>
</html>