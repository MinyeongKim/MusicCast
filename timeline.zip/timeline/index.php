<?php
//   include "db.php";
?>
<!doctype html>
<html lang="ko">
	<head>
		<meta charset="UTF-8">
		<title>게시판</title>
		<link rel="stylesheet" href="style.css"/>
	</head>
	<body>
		<h1>댓글</h1>
	<form action="write_ok.php" method="post">
                    <table id="boardWrite">
                        <tr>
                            <td class="tb"><label for="ucontent">내용</label></td>
                            <td height="30"><textarea name="content" id="ucontent" rows="10" cols="37"></textarea></td>
                        </tr>
                    </table>
                <div class="bt_se">
                    <button>작성</button>
                </div>
            </form>
		<div id ="board_area">
			<table class = "list-table">
				<thead>
				<tr>
				<th width ="120">글쓴이</th>
				<th width ="500">내용</th>
				<th width ="100">작성일</th>
				</tr>
				</thead>
<?php

$mysql_hostname = 'localhost';
$mysql_username = 'root';
$mysql_password = 'apmsetup';
$mysql_database = 'boardtest';

// DB 연결
$connect = mysql_connect($mysql_hostname, $mysql_username, $mysql_password);

// DB 선택
mysql_select_db($mysql_database, $connect) or die('DB 선택 실패');

   $sql = "select * from board order by indx desc";
   // mq - mysql_query 의 약자
   // BoardTest 안의 모든 컬럼들을 가져오고 index 번호에 따라 내림차순으로 5개 출력.
   $result = mysql_query($sql, $connect);
   //echo $result;
   while($board = mysql_fetch_array($result)){
   // 보냈던 쿼리의 행이 끝날때까지 자동으로 반복실행
   $title = $board[title]; // board 테이블의 title 값 저장
   if(strlen($title)>30){
      $title = str_replace($board[title],mb_substr($board[title],0,30,"utf-8")."...",$board['title']);
      // 제목이 일정 길이 초과시 초과한 문자 대신 '...' 출력 (31 부터는 ... 출력)
   }
?>

<tbody>
<tr>
<td width="120"><?php echo $board['name']; ?></td>
<td width="500"><?php echo $board['content'];?></td>
<td width="100"><?php echo $board['date']; ?></td>
<!-- 글을 읽을때 해당 글의 번호를 가져옴 -->

</tr>
</tbody>
<?php } ?>
</table>
<form action="write.php">
<div class="write_btn">
<button>글쓰기</button>
</div>
</form>
</div>
	</body>
</html>