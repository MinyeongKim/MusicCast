<?php
header('Content-Type: text/html; charset=utf-8');

$mysql_hostname = 'localhost';
$mysql_username = 'root';
$mysql_password = 'apmsetup';
$mysql_database = 'boardtest';

// DB 연결
$connect = mysql_connect($mysql_hostname, $mysql_username, $mysql_password);

// DB 선택
mysql_select_db($mysql_database, $connect) or die('DB 선택 실패');

$name =$_POST['name'];
$pw =$_POST['pw']; // md5($_POST['pw'])
$title =$_POST['title'];
$content =$_POST['content'];


//include "../db.php";
$date = date('Y-m-d');
$sql = "insert into board(name,pw,title,content,date,hit,indx) values('$name','$pw','$title','$content','$date',0,'0')";
mysql_query($sql, $connect);

echo "<script>alert('글쓰기가 완료되었습니다.');</script> "; 
mysql_close($connect);
?>
<meta http-equiv="refresh" content="0 url=/index.php" />