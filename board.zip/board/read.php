<?php
//include "../db.php";

header('Content-Type: text/html; charset=utf-8');

$mysql_hostname = 'localhost';
$mysql_username = 'root';
$mysql_password = 'apmsetup';
$mysql_database = 'boardtest';

// DB 연결
$connect = mysql_connect($mysql_hostname, $mysql_username, $mysql_password);
// DB 선택
mysql_select_db($mysql_database, $connect) or die('DB 선택 실패');

	$bno = $_GET["indx"];
	$sql = "select * from board where indx='".$bno."'";

	$result = mysql_query($sql, $connect);
	$board = mysql_fetch_array($result);
/* 조회수 카운트 */

	$sql_hit = "select * from board where indx ='".$bno."'";
	$result_hit = mysql_query($sql_hit,$connect);
	$hit = mysql_fetch_array($result_hit);
	$hit = $hit['hit'] + 1;
	$fet = mysql_query("update board set hit = '".$hit."' where indx = '".$bno."'", $connect);


	?>
<!doctype html>
<html lang="ko">
 <head>
  <meta charset="UTF-8">
  <title>게시판</title>
  <link rel="stylesheet" href="../style.css" />
 </head>
 <body>
 <div id="board_read">
<table>
	<tr>
		<td class="read w10 fl">제목</td>
		<td class="read_con">&nbsp;<?php echo $board['title'];?></td>
	</tr>
	<tr>
		<td class="read w5 fl">번호</td>
		<td class="read_con">&nbsp;<?php echo $board['indx'];?></td>
	</tr>
	<tr>
		<td class="read w10 fl">작성자</td>
		<td class="read_con">&nbsp;<?php echo $board['name'];?></td>
	</tr>
	<tr>
		<td class="read w10 fl">등록일</td>
		<td class="read_con">&nbsp;<?php echo $board['date'];?></td>
	</tr>
	<tr>
		<td class="read w10 fl">조회수</td>
		<td class="read_con">&nbsp;<?php echo $board['hit']+1;?></td>
	</tr>
	<tr>
		<td class="read_nl fl">내용</td>
		<td class="read_nl_con"><?php echo nl2br("$board[content]");  ?></td>
		<td><?php echo("<br><br><video src=test.mp4 controls></video>");?></td>
	</tr>
</table>
</div>
<div class="bo_ser">
	<ul>
		<li><a href="index.php">[목록으로]</a></li>
		<li><a href="modify.php?indx=<?php echo $board['indx']; ?>">[수정]</a></li>
		<li><a href="delete.php?indx=<?php echo $board['indx']; ?>">[삭제]</a></li>
	</ul>
</div>
 </body>
</html>